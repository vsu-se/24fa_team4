package ebay;


//Class to create a bid
public class Bid {
    int bidID;
    float amount;
    Bidder bidder;
    Auction auction;

}
