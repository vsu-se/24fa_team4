package ebay;

public class Report {
    String reportData;

    public Report(){
    }
// Generate a report on an Auction
    public String generateReport(User user){

        return this.reportData;
    }
}
