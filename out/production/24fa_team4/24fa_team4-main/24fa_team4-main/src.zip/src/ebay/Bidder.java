package ebay;

import java.util.List;

public class Bidder extends User{

    public Bidder(String name, String email, String password){
        super(name, email, password);
    }

    //bidOnItem(Auction, Item, float)
    //generateBuyerReport(): Report
    //showActiveBids(): List<Auction>

    //Method for bidder to bid on an item
    public void bidOnItem(Auction auction, Item item, float num){

    }

    //Shows a report of the buyer history
    public Report generateBuyerReport(){

    }

    //Shows a list of the active bids for the bidder
    public List<Auction> showActiveBids(){

    }
}
