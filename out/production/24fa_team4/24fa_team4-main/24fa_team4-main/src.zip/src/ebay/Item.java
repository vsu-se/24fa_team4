package ebay;

public class Item {

    int itemID;
    String name;
    String description;
    float startingPrice;

    public Item(){

    }
// Adds an item to be auctioned off
    public void addItemToAuction(Auction auction){

    }
}
