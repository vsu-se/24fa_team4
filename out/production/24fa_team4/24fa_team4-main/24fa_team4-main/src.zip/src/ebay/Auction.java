package ebay;

import java.time.LocalDateTime;
import java.util.List;

public class Auction {
    int auctionID;
    LocalDateTime startTime;
    LocalDateTime endTime;
    Seller seller;
    //List<Items> items;

    public Auction(){

    }
// Method to end auction
    public void endAuction(){

    }
// Get the bid history of an auction
//    public List<Bid> getBidHistory(){
//    }

    //Method to tell if auction is still active
    public boolean isAuctionActive(){

        return false;
    }
}
