package ebay;

import java.time.LocalDateTime;
import java.util.List;

public class AuctionSystem {

    LocalDateTime currentTime;
    SystemState state;

    public AuctionSystem(){

    }
//Add categories to Items
    public void addCategory(Category category){

    }
//Set the sellers commission
    public void setSellersCommission(float num){

    }
//Set the buyers premium
    public void setBuyersPremium(float num){

    }
//List an item for auction
    public void listItemForAuction(Item item){

    }
// A list of the current and upcoming auctions
//    public List<Auction> showCurrentAndUpcomingAuctions(){
//
//    }
    
    public void saveSystemState(){

    }

    public void restoreSystemState(){

    }

    public void returnToRealTime(){

    }

}
