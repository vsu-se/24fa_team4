package ebay;
import java.awt.*;
import java.util.List;

public class SystemState {
    List<Auction> auctions;
    List<User> users;

    public SystemState(){

    }
// Creates a save state for a user
    public void saveState(){

    }
//Restores a user back to their previous state
    public void restoreState(){

    }
}
