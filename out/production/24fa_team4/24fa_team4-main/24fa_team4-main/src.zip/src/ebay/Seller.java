package ebay;

public class Seller extends User {
    public Seller(String name, String email, String password){
        super(name, email, password);
    }



    public void listAuction(Auction auction){

    }
//Generate report on Seller history
//    public Report generateSellerReport(){
//
//    }
}
