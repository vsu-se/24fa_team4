package ebay;

//Class to create users and possibly store them.
public abstract class User {
    int userID;
    String name;
    String email;
    String password;

    public User(String name, String email, String password){
        this.name = name;
        this.email = email;
        this.password = password;

    }
}
