package ebay;

public class AuctionManager {

    public AuctionManager(){

    }
// List the active auctions
//    public List<Auction> listActiveAuctions(){
//
//    }
//List concluded auctions
//    public List<Auction> listConcludedAuctions(){
//
//    }
}
